﻿using Moq;
using System;
using System.Collections.Generic;
using Xunit;
using BookifyAPI.Controllers;
using BookifyAPI.Models;
using BookifyAPI.Services;
using BookifyAPI.Repositories;
using FluentValidation;
using FluentValidation.Results;
using Microsoft.AspNetCore.Mvc;

namespace BookifyAPI.UnitTest
{
    public class CalendarControllerTests
    {
        private readonly Mock<ISalesRepository> _mockSalesRepository;
        private readonly Mock<IValidator<QueryRequest>> _mockValidator;
        private readonly SalesService _salesService;
        private readonly CalendarController _controller;

        public CalendarControllerTests()
        {
            // Mock the repository layer for SalesService dependency
            _mockSalesRepository = new Mock<ISalesRepository>();

            // Create an instance of SalesService with the mocked repository
            _salesService = new SalesService(_mockSalesRepository.Object);

            // Mock the FluentValidation validator
            _mockValidator = new Mock<IValidator<QueryRequest>>();

            // Instantiate the controller with the SalesService and mocked validator
            _controller = new CalendarController(_salesService, _mockValidator.Object);
        }

        [Fact]
        public async Task QueryAvailableSlots_ReturnsAvailableSlotsOnly()
        {
            // Arrange
            var request = new QueryRequest
            {
                Language = "German",
                Rating = "Bronze",
                Products = new List<string> { "SolarPanels" },
                Date = "2024-05-03"
            };

            _mockValidator.Setup(v => v.ValidateAsync(request, default))
                .ReturnsAsync(new ValidationResult());

            var mockAvailableSlots = new List<AvailableSlot>
            {
                new AvailableSlot { Start_date = "2024-05-03T10:30:00", Available_count = 5 },
                new AvailableSlot { Start_date = "2024-05-03T11:30:00", Available_count = 3 }
            };

            _mockSalesRepository.Setup(repo => repo.GetAvailableSalesSlotsAsync(request))
                .ReturnsAsync(mockAvailableSlots);

            // Act
            var result = await _controller.QueryAvailableSlots(request);

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result);
            var returnedSlots = Assert.IsType<List<AvailableSlot>>(okResult.Value);
            Assert.Equal(2, returnedSlots.Count);
            Assert.Contains(returnedSlots, slot => slot.Start_date == "2024-05-03T10:30:00");
            Assert.Contains(returnedSlots, slot => slot.Start_date == "2024-05-03T11:30:00");
        }

        [Theory]
        [InlineData("2024-05-03T10:30:00.000")]
        [InlineData("invalid-date")]
        [InlineData("2024-18-03")]
        public async Task QueryAvailableSlots_ReturnsBadRequest_WhenValidationFails(string dt)
        {
            // Arrange
            var request = new QueryRequest
            {
                Language = "German",
                Rating = "Bronze",
                Products = new List<string> { "SolarPanels" },
                Date = dt
            };

            var validationFailures = new List<ValidationFailure>
            {
                new ValidationFailure("Date", "Invalid date format.")
            };
            _mockValidator.Setup(v => v.ValidateAsync(request, default))
                .ReturnsAsync(new ValidationResult(validationFailures));

            // Act
            var result = await _controller.QueryAvailableSlots(request);

            // Assert
            var badRequestResult = Assert.IsType<BadRequestObjectResult>(result);
            var modelState = Assert.IsType<SerializableError>(badRequestResult.Value);
            Assert.Contains("Date", modelState.Keys);
        }

        [Fact]
        public async Task QueryAvailableSlots_ReturnsEmptyList_WhenNoAvailableSlots()
        {
            // Arrange
            var request = new QueryRequest
            {
                Language = "English",
                Rating = "Gold",
                Products = new List<string> { "SolarPanels" },
                Date = "2024-05-03"
            };

            _mockValidator.Setup(v => v.ValidateAsync(request, default))
                .ReturnsAsync(new ValidationResult());

            var mockAvailableSlots = new List<AvailableSlot>();
            _mockSalesRepository.Setup(repo => repo.GetAvailableSalesSlotsAsync(request))
                .ReturnsAsync(mockAvailableSlots);

            // Act
            var result = await _controller.QueryAvailableSlots(request);

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result);
            var returnedSlots = Assert.IsType<List<AvailableSlot>>(okResult.Value);
            Assert.Empty(returnedSlots);
        }

        [Fact]
        public async Task QueryAvailableSlots_ReturnsBadRequest_WhenRequestIsNull()
        {
            // Arrange
            QueryRequest invalidRequest = null;

            // Act
            var result = await _controller.QueryAvailableSlots(invalidRequest);

            // Assert
            Assert.IsType<BadRequestObjectResult>(result);
        }

        [Fact]
        public async Task QueryAvailableSlots_ReturnsBadRequest_WhenLanguageIsMissing()
        {
            // Arrange
            var request = new QueryRequest
            {
                Rating = "Gold",
                Products = new List<string> { "SolarPanels", "Heatpump" },
                Language = "",
                Date = "2024-05-02"
            };

            var validationFailures = new List<ValidationFailure>
            {
                new ValidationFailure("Language", "Language is required.")
            };
            _mockValidator.Setup(v => v.ValidateAsync(request, default))
                .ReturnsAsync(new ValidationResult(validationFailures));

            // Act
            var result = await _controller.QueryAvailableSlots(request);

            // Assert
            var badRequestResult = Assert.IsType<BadRequestObjectResult>(result);
            var modelState = Assert.IsType<SerializableError>(badRequestResult.Value);
            Assert.Contains("Language", modelState.Keys);
        }

        [Fact]
        public async Task QueryAvailableSlots_ReturnsBadRequest_WhenRatingIsMissing()
        {
            // Arrange
            var request = new QueryRequest
            {
                Language = "English",
                Products = new List<string> { "SolarPanels", "Heatpump" },
                Date = "2024-05-02"
            };

            var validationFailures = new List<ValidationFailure>
            {
                new ValidationFailure("Rating", "Rating is required.")
            };
            _mockValidator.Setup(v => v.ValidateAsync(request, default))
                .ReturnsAsync(new ValidationResult(validationFailures));

            // Act
            var result = await _controller.QueryAvailableSlots(request);

            // Assert
            var badRequestResult = Assert.IsType<BadRequestObjectResult>(result);
            var modelState = Assert.IsType<SerializableError>(badRequestResult.Value);
            Assert.Contains("Rating", modelState.Keys);
        }

        [Fact]
        public async Task QueryAvailableSlots_ReturnsBadRequest_WhenProductsAreNull()
        {
            // Arrange
            var request = new QueryRequest
            {
                Language = "English",
                Rating = "5",
                Products = null,
                Date = "2024-05-02"
            };

            var validationFailures = new List<ValidationFailure>
            {
                new ValidationFailure("Products", "Products cannot be null.")
            };
            _mockValidator.Setup(v => v.ValidateAsync(request, default))
                .ReturnsAsync(new ValidationResult(validationFailures));

            // Act
            var result = await _controller.QueryAvailableSlots(request);

            // Assert
            var badRequestResult = Assert.IsType<BadRequestObjectResult>(result);
            var modelState = Assert.IsType<SerializableError>(badRequestResult.Value);
            Assert.Contains("Products", modelState.Keys);
        }

        [Fact]
        public async Task QueryAvailableSlots_ReturnsBadRequest_WhenProductsAreEmpty()
        {
            // Arrange
            var request = new QueryRequest
            {
                Language = "English",
                Rating = "Gold",
                Products = new List<string>(),
                Date = "2024-05-02"
            };

            var validationFailures = new List<ValidationFailure>
            {
                new ValidationFailure("Products", "Products cannot be empty.")
            };
            _mockValidator.Setup(v => v.ValidateAsync(request, default))
                .ReturnsAsync(new ValidationResult(validationFailures));

            // Act
            var result = await _controller.QueryAvailableSlots(request);

            // Assert
            var badRequestResult = Assert.IsType<BadRequestObjectResult>(result);
            var modelState = Assert.IsType<SerializableError>(badRequestResult.Value);
            Assert.Contains("Products", modelState.Keys);
        }
    }
}
