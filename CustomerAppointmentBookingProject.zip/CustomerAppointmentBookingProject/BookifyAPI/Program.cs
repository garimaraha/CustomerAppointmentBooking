using BookifyAPI.Data;
using BookifyAPI.Repositories;
using BookifyAPI.Services;
using BookifyAPI.Validators;
using FluentValidation;

var builder = WebApplication.CreateBuilder(args);




// Add services to the container.
builder.Services.AddSingleton<DatabaseContext>();
builder.Services.AddTransient<ISalesRepository, SalesRepository>();
builder.Services.AddTransient<SalesService>();

// Register validators from the assembly containing QueryRequestValidator
builder.Services.AddValidatorsFromAssemblyContaining<QueryRequestValidator>();


builder.Services.AddControllers();


var app = builder.Build();



app.UseHttpsRedirection();

app.UseAuthorization();

app.MapControllers();

app.Run();
