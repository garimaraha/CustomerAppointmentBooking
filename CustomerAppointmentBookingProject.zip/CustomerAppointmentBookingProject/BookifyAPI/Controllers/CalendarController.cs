﻿using BookifyAPI.Models;
using BookifyAPI.Services;
using Microsoft.AspNetCore.Mvc;
using FluentValidation;


namespace BookifyAPI.Controllers
{

    [Route("calendar")]
    [ApiController]

    // CalendarController handles requests related to calendar operations, such as querying available slots.
    public class CalendarController : ControllerBase
    {
        private readonly SalesService _service;
        private readonly IValidator<QueryRequest> _validator;


        // Constructor to inject the SalesService dependency
        public CalendarController(SalesService service, IValidator<QueryRequest> validator)
        {
            _service = service;
            _validator = validator;
        }

        /// <summary>
        /// Queries available slots based on the specified input criteria.
        /// </summary>
        /// <param name="request">The request containing the query parameters such as date, products, language, and rating.</param>
        /// <returns>A list of available slots matching the criteria.</returns>

        [HttpPost("query")]
        public async Task<IActionResult> QueryAvailableSlots([FromBody] QueryRequest request)
        {
            // Check if the request object is null and return a BadRequest response if true
            if (request == null)
            {
                return BadRequest("Request cannot be null.");
            }

            // Validate the request object using FluentValidation
            var validationResult = await _validator.ValidateAsync(request);

            // If validation fails, add errors to ModelState and return a BadRequest response
            if (!validationResult.IsValid)
            {
                foreach (var error in validationResult.Errors)
                {
                    ModelState.AddModelError(error.PropertyName, error.ErrorMessage);
                }
                return BadRequest(ModelState);
            }

            // Execute the main business logic to retrieve available slots based on the request
            var result = await _service.GetAvailableSlotsAsync(request);
            // Return the result with a 200 status
            return Ok(result);

        }
    }
}
