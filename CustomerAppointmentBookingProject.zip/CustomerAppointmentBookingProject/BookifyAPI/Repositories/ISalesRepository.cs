﻿using BookifyAPI.Models;

namespace BookifyAPI.Repositories
{
    // Interface defining the contract for sales-related data access operations
    public interface ISalesRepository
    {
        // Asynchronous method to retrieve a list of available sales slots
        // Parameters:
        //   - request: A QueryRequest object containing filtering criteria such as date, language, rating, and products
        // Returns:
        //   - A Task representing an asynchronous operation that returns a list of AvailableSlot objects

        Task<List<AvailableSlot>> GetAvailableSalesSlotsAsync(QueryRequest request);
    }
}
