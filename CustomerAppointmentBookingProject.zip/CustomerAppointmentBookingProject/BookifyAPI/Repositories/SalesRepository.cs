﻿using BookifyAPI.Data; // Importing the data context for database operations
using BookifyAPI.Models; // Importing models for query and data mapping
using Dapper; // Dapper for simplified data access and mapping

namespace BookifyAPI.Repositories
{
    // This class implements ISalesRepository and handles data operations related to sales slots
    public class SalesRepository : ISalesRepository
    {
        private readonly DatabaseContext _context; // Database context for creating connections

        // Constructor injection for database context
        public SalesRepository(DatabaseContext context)
        {
            _context = context;
        }

        // Method to retrieve available sales slots based on the provided request criteria
        public async Task<List<AvailableSlot>> GetAvailableSalesSlotsAsync(QueryRequest request)
        {
            // SQL query that calls a PostgreSQL function with parameters to get available slots
            var query = @"SELECT start_date, available_count 
                      FROM get_available_slots(
                      @Language::TEXT,  
                      @Rating::TEXT,  
                      @Products::TEXT[], 
                      @Date::DATE  
                  );";

            // Establish a connection to the database
            using var connection = _context.CreateConnection();

            // Map request properties to query parameters
            var parameters = new
            {
                Language = request.Language, // Language input from request
                Rating = request.Rating, // Rating input from request
                Products = request.Products.ToArray(), // Convert products list to array
                Date = request.Date // Date input from request
            };

            // Execute the query asynchronously using Dapper
            var slots = await connection.QueryAsync<AvailableSlot>(query, parameters);
            return slots.AsList(); // Convert the result to a list and return
        }
    }
}
