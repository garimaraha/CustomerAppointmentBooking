﻿using BookifyAPI.Models; // Importing models for data structures like QueryRequest and AvailableSlot
using BookifyAPI.Repositories; // Importing the repository interface for database interactions

namespace BookifyAPI.Services
{
    // The SalesService class encapsulates business logic related to sales operations
    public class SalesService
    {
        private readonly ISalesRepository _repository; // Interface for data access, promotes dependency injection

        // Constructor injection of ISalesRepository
        public SalesService(ISalesRepository repository)
        {
            _repository = repository;
        }

        // Asynchronous method to get available slots based on a provided request
        public async Task<List<AvailableSlot>> GetAvailableSlotsAsync(QueryRequest request)
        {
            // Calls the repository method to retrieve available sales slots based on the request
            return await _repository.GetAvailableSalesSlotsAsync(request);
        }
    }
}
