﻿using System.ComponentModel.DataAnnotations;

namespace BookifyAPI.Models  // Organizing related classes under a namespace
{
    // This class represents the data structure for a query request to fetch available slots.
    public class QueryRequest
    {
        // Date for which the query is being made
        [RegularExpression(@"^\d{4}-\d{2}-\d{2}$", ErrorMessage = "Invalid date format. Expected format: yyyy-MM-dd.")]
        public string Date { get; set; }

        // List of products that the query pertains to (e.g., SolarPanels, Heatpumps)
        public List<string> Products { get; set; }

        // Language preference for matching sales managers
        public string Language { get; set; }

        // Customer rating to be matched (e.g., Gold, Silver)
        public string Rating { get; set; }
    }
}
