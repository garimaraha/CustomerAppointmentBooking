﻿namespace BookifyAPI.Models  // Organizing related classes under a namespace
{
    // This class represents an available slot for a sales manager query
    public class AvailableSlot
    {
        // Start date and time of the available slot as a string
        public string Start_date { get; set; } = "";

        // Property to hold available_count and cast it to int from a private long variable
        private long _availableCount;
        public int Available_count
        {
            get => (int)_availableCount;  // Converts _availableCount from long to int when accessed
            set => _availableCount = value;  // Allows setting _availableCount directly
        }
    }
}
