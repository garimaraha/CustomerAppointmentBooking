﻿using Microsoft.Extensions.Configuration;  // For accessing configuration settings
using Npgsql;  // For working with PostgreSQL database connections
using System.Data;  // Provides IDbConnection interface

namespace BookifyAPI.Data  // Namespace for organizing related classes
{
    // This class handles creating and managing connections to the database.
    public class DatabaseContext
    {
        private readonly IConfiguration _configuration;  // Interface for accessing configuration settings
        private readonly string _connectionString;  // Connection string to the PostgreSQL database

        // Constructor that accepts an IConfiguration object to access configuration settings
        public DatabaseContext(IConfiguration configuration)
        {
            _configuration = configuration;  // Assign the passed-in configuration object
            // Retrieve the connection string from configuration settings (e.g., appsettings.json)
            _connectionString = _configuration.GetConnectionString("DefaultConnection") ?? "";
        }

        // Method to create and return a new database connection using Npgsql
        public IDbConnection CreateConnection()
        {
            // Create a new PostgreSQL connection using the connection string
            return new NpgsqlConnection(_connectionString);
        }
    }
}
