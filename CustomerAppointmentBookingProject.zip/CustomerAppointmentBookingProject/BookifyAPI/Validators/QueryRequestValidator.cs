﻿using BookifyAPI.Models;
using FluentValidation;
namespace BookifyAPI.Validators
{
    public class QueryRequestValidator : AbstractValidator<QueryRequest>
    {
        public QueryRequestValidator()
        {
            // Validate that Date is in correct format
            RuleFor(x => x.Date)
                .Matches(@"^\d{4}-\d{2}-\d{2}$").WithMessage("Invalid date format. Expected format: yyyy-MM-dd.");

            // Validate that Language, Rating, and Products are provided
            RuleFor(x => x.Language)
                .NotEmpty().WithMessage("Language is required.");

            RuleFor(x => x.Rating)
                .NotEmpty().WithMessage("Rating is required.");

            RuleFor(x => x.Products)
                .NotNull().WithMessage("Products cannot be null.")
                .NotEmpty().WithMessage("Products cannot be empty.");
        }
    }
}
