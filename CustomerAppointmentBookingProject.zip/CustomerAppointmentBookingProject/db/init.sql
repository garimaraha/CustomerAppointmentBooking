create table if not exists  sales_managers (
    id serial primary key not null,
    name varchar(250) not null,
    languages varchar(100)[],
    products varchar(100)[],
    customer_ratings varchar(100)[]
);

create table if not exists slots (
    id serial primary key not null,
    start_date timestamptz not null,
    end_date timestamptz not null,
    booked boolean not null default false,
    sales_manager_id int not null references sales_managers(Id)
);

CREATE INDEX IF NOT EXISTS idx_sales_managers_languages_gin ON sales_managers USING GIN (languages);
CREATE INDEX IF NOT EXISTS idx_sales_managers_customer_ratings_gin ON sales_managers USING GIN (customer_ratings);
CREATE INDEX IF NOT EXISTS idx_sales_managers_products_gin ON sales_managers USING GIN (products);
CREATE INDEX IF NOT EXISTS idx_slots_start_date ON slots (start_date);
CREATE INDEX IF NOT EXISTS idx_slots_sales_manager_id_booked ON slots (sales_manager_id, booked);
CREATE INDEX IF NOT EXISTS idx_slots_composite ON slots (sales_manager_id, start_date, end_date, booked);



insert into sales_managers (name, languages, products, customer_ratings) values ('Seller 1', '{"German"}', '{"SolarPanels"}', '{"Bronze"}');
insert into sales_managers (name, languages, products, customer_ratings) values ('Seller 2', '{"German", "English"}', '{"SolarPanels", "Heatpumps"}', '{"Gold","Silver","Bronze"}');
insert into sales_managers (name, languages, products, customer_ratings) values ('Seller 3', '{"German", "English"}', '{"Heatpumps"}', '{"Gold","Silver","Bronze"}');

insert into slots (sales_manager_id, booked, start_date, end_date) values (1, false, '2024-05-03T10:30Z', '2024-05-03T11:30Z');
insert into slots (sales_manager_id, booked, start_date, end_date) values (1, true,  '2024-05-03T11:00Z', '2024-05-03T12:00Z');
insert into slots (sales_manager_id, booked, start_date, end_date) values (1, false, '2024-05-03T11:30Z', '2024-05-03T12:30Z');
insert into slots (sales_manager_id, booked, start_date, end_date) values (2, false, '2024-05-03T10:30Z', '2024-05-03T11:30Z');
insert into slots (sales_manager_id, booked, start_date, end_date) values (2, false, '2024-05-03T11:00Z', '2024-05-03T12:00Z');
insert into slots (sales_manager_id, booked, start_date, end_date) values (2, false, '2024-05-03T11:30Z', '2024-05-03T12:30Z');
insert into slots (sales_manager_id, booked, start_date, end_date) values (3, true,  '2024-05-03T10:30Z', '2024-05-03T11:30Z');
insert into slots (sales_manager_id, booked, start_date, end_date) values (3, false, '2024-05-03T11:00Z', '2024-05-03T12:00Z');
insert into slots (sales_manager_id, booked, start_date, end_date) values (3, false, '2024-05-03T11:30Z', '2024-05-03T12:30Z');
insert into slots (sales_manager_id, booked, start_date, end_date) values (1, false, '2024-05-04T10:30Z', '2024-05-04T11:30Z');
insert into slots (sales_manager_id, booked, start_date, end_date) values (1, false, '2024-05-04T11:00Z', '2024-05-04T12:00Z');
insert into slots (sales_manager_id, booked, start_date, end_date) values (1, true,  '2024-05-04T11:30Z', '2024-05-04T12:30Z');
insert into slots (sales_manager_id, booked, start_date, end_date) values (2, true,  '2024-05-04T10:30Z', '2024-05-04T11:30Z');
insert into slots (sales_manager_id, booked, start_date, end_date) values (2, false, '2024-05-04T11:00Z', '2024-05-04T12:00Z');
insert into slots (sales_manager_id, booked, start_date, end_date) values (2, true,  '2024-05-04T11:30Z', '2024-05-04T12:30Z');
insert into slots (sales_manager_id, booked, start_date, end_date) values (3, true,  '2024-05-04T10:30Z', '2024-05-04T11:30Z');
insert into slots (sales_manager_id, booked, start_date, end_date) values (3, false, '2024-05-04T11:00Z', '2024-05-04T12:00Z');
insert into slots (sales_manager_id, booked, start_date, end_date) values (3, false, '2024-05-04T11:30Z', '2024-05-04T12:30Z');


-- ====================================================================================
-- Function: get_available_slots
-- Purpose : This function retrieves available slots for sales managers based on 
--           specific input criteria such as language, customer rating, and products.
--           It is designed to match customers' preferences with available sales 
--           manager slots and exclude any slots that overlap with existing booked slots.
-- 
-- Parameters:
--   - input_language: Desired language for matching sales managers (Text).
--   - input_rating: Customer rating that must be matched (TEXT).
--   - input_products: Array of products that sales managers must handle (TEXT[]).
--   - input_date: Date for which available slots need to be checked (DATE).
--
-- Returns:
--   - start_time: Start time of the available slot (Text).
--   - available_count: Number of distinct sales managers available for each slot (BIGINT).
--
-- Notes:
--   - Uses GIN indexing for array columns to enhance performance.
--   - Applies date range filtering to ensure only slots within the specified date are considered.
--   - Excludes slots that overlap with booked slots to ensure accurate availability.
-- ====================================================================================
DO $$
BEGIN
    -- Check if the function already exists
    IF EXISTS (
        SELECT 1
        FROM pg_proc
        WHERE proname = 'get_available_slots'
    ) THEN
        -- If it exists, drop it
        DROP FUNCTION get_available_slots(TEXT, TEXT, TEXT[], DATE);
    END IF;
END
$$;
CREATE FUNCTION get_available_slots(
    input_language TEXT,  -- Input parameter for the desired language
    input_rating TEXT,    -- Input parameter for the desired rating
    input_products TEXT[],-- Input array parameter for the desired products
    input_date DATE       -- Input parameter for the date to check availability
)
RETURNS TABLE (Start_date TEXT, available_count BIGINT) AS $$
BEGIN
    RETURN QUERY
    -- Step 1: Filter matching sales managers based on input criteria
    WITH MatchingSalesManagers AS (
        SELECT id
        FROM sales_managers
        WHERE input_language = ANY(languages)  -- Match sales managers who speak the input language
          AND input_rating = ANY(customer_ratings)  -- Match sales managers with the specified customer rating
          AND products::TEXT[] @> input_products  -- Cast products to TEXT[] for comparison
    ),
    -- Step 2: Retrieve available slots for these sales managers, excluding overlapping booked slots
    AvailableSlots AS (
        SELECT s.start_date AS slot_start, s.sales_manager_id, s.end_date
        FROM slots s
        INNER JOIN MatchingSalesManagers msm ON s.sales_manager_id = msm.id  -- Join to filter by matching sales managers
        WHERE s.start_date >= input_date::timestamptz  -- Filter slots starting from the input date
          AND s.start_date < (input_date::timestamptz + interval '1 day')  -- Filter slots within the same day
          AND s.booked = false  -- Only consider unbooked slots
          AND NOT EXISTS (  -- Exclude slots that overlap with booked slots for the same sales manager
              SELECT 1
              FROM slots b
              WHERE b.sales_manager_id = s.sales_manager_id
                AND b.booked = true  -- Look for conflicting booked slots
                AND b.start_date < s.end_date AND b.end_date > s.start_date  -- Check for overlap with available slots
          )
    )
    -- Step 3: Aggregate the available slots, counting distinct sales managers for each slot
    SELECT  TO_CHAR(slot_start AT TIME ZONE 'UTC', 'YYYY-MM-DD"T"HH24:MI:SS.MS"Z"') AS start_time, COUNT(DISTINCT sales_manager_id) AS available_count
    FROM AvailableSlots
    GROUP BY slot_start
    ORDER BY slot_start;  -- Order the results by start time
END;
$$ LANGUAGE plpgsql;





